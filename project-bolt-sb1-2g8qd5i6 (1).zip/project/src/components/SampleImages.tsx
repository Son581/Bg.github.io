import React from 'react';

const sampleImages = [
  {
    id: 1,
    url: 'https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?auto=format&fit=crop&w=500&q=80',
    title: 'Car on Road',
  },
  {
    id: 2,
    url: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=500&q=80',
    title: 'Portrait',
  },
  {
    id: 3,
    url: 'https://images.unsplash.com/photo-1526047932273-341f2a7631f9?auto=format&fit=crop&w=500&q=80',
    title: 'Product Shot',
  },
];

export function SampleImages() {
  return (
    <section id="samples" className="py-12 bg-gray-800">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-white mb-8">Sample Images</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {sampleImages.map((image) => (
            <div key={image.id} className="bg-gray-700 rounded-lg overflow-hidden">
              <img
                src={image.url}
                alt={image.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h3 className="text-white font-semibold">{image.title}</h3>
                <p className="text-gray-400 text-sm mt-1">Click to try with this image</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}