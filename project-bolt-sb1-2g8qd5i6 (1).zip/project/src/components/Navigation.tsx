import React from 'react';
import { Eraser } from 'lucide-react';

export function Navigation() {
  return (
    <nav className="bg-gray-900 py-4">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Eraser className="h-8 w-8 text-blue-500" />
            <span className="text-2xl font-bold text-white">MagicErase</span>
          </div>
          <div className="flex space-x-6">
            <a href="#" className="text-white hover:text-blue-400 transition-colors">Home</a>
            <a href="#samples" className="text-white hover:text-blue-400 transition-colors">Samples</a>
            <a href="#about" className="text-white hover:text-blue-400 transition-colors">About</a>
            <a href="#contact" className="text-white hover:text-blue-400 transition-colors">Contact</a>
          </div>
        </div>
      </div>
    </nav>
  );
}