import axios from 'axios';

const API_KEY = 'YMaVEvwi6WVuMoAMWtrYzRic';
const API_URL = 'https://api.remove.bg/v1.0/removebg';

export async function removeBackground(imageFile: File): Promise<string> {
  const formData = new FormData();
  formData.append('image_file', imageFile);
  formData.append('size', 'auto');

  try {
    const response = await axios.post(API_URL, formData, {
      headers: {
        'X-Api-Key': API_KEY,
      },
      responseType: 'arraybuffer',
    });

    // Convert arraybuffer to base64
    const arrayBufferView = new Uint8Array(response.data);
    const blob = new Blob([arrayBufferView], { type: 'image/png' });
    return URL.createObjectURL(blob);
  } catch (error) {
    console.error('Error removing background:', error);
    throw new Error('Failed to process image');
  }
}