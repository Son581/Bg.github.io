import React, { useState, useCallback, useEffect } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, Image as ImageIcon, Trash2, Download, Loader2 } from 'lucide-react';
import { Navigation } from './components/Navigation';
import { SampleImages } from './components/SampleImages';
import { removeBackground } from './api';

interface FileWithPreview extends File {
  preview?: string;
}

function App() {
  const [file, setFile] = useState<FileWithPreview | null>(null);
  const [processedImage, setProcessedImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Cleanup object URLs when component unmounts or when they're no longer needed
  useEffect(() => {
    return () => {
      if (file?.preview) {
        URL.revokeObjectURL(file.preview);
      }
      if (processedImage) {
        URL.revokeObjectURL(processedImage);
      }
    };
  }, []);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      const fileWithPreview = Object.assign(file, {
        preview: URL.createObjectURL(file)
      });
      setFile(fileWithPreview);
      setProcessedImage(null);
      setError(null);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.png', '.jpg', '.jpeg', '.webp']
    },
    maxSize: 25 * 1024 * 1024, // 25MB
    multiple: false
  });

  const handleRemoveBackground = async () => {
    if (!file) return;
    setIsProcessing(true);
    setError(null);
    
    try {
      const result = await removeBackground(file);
      if (processedImage) {
        URL.revokeObjectURL(processedImage);
      }
      setProcessedImage(result);
    } catch (err) {
      setError('Failed to process image. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleReset = () => {
    if (file?.preview) {
      URL.revokeObjectURL(file.preview);
    }
    if (processedImage) {
      URL.revokeObjectURL(processedImage);
    }
    setFile(null);
    setProcessedImage(null);
    setError(null);
  };

  const handleDownload = () => {
    if (processedImage) {
      const link = document.createElement('a');
      link.href = processedImage;
      link.download = 'processed-image.png';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white">
      <Navigation />
      
      <div className="container mx-auto px-4 py-8">
        <header className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Remove Image Background</h1>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Upload your image and let our AI remove the background instantly. 
            Supports JPG, PNG, and WebP formats up to 25MB.
          </p>
        </header>

        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Upload Section */}
            <div className="bg-gray-800 rounded-xl p-6">
              <div
                {...getRootProps()}
                className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors
                  ${isDragActive ? 'border-blue-500 bg-blue-500/10' : 'border-gray-600 hover:border-gray-500'}`}
              >
                <input {...getInputProps()} />
                <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <p className="text-gray-300 mb-2">
                  {isDragActive
                    ? "Drop your image here"
                    : "Drag & drop your image here"}
                </p>
                <p className="text-gray-500 text-sm">or click to select</p>
              </div>

              {file && (
                <div className="mt-4">
                  <img
                    src={file.preview}
                    alt="Preview"
                    className="rounded-lg w-full object-cover"
                    style={{ maxHeight: '300px' }}
                  />
                  <div className="flex justify-between mt-4">
                    <button
                      onClick={handleReset}
                      className="flex items-center px-4 py-2 bg-red-600 hover:bg-red-700 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      Remove
                    </button>
                    <button
                      onClick={handleRemoveBackground}
                      disabled={isProcessing}
                      className={`flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors
                        ${isProcessing ? 'opacity-50 cursor-not-allowed' : ''}`}
                    >
                      {isProcessing ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Processing...
                        </>
                      ) : (
                        <>
                          <ImageIcon className="w-4 h-4 mr-2" />
                          Remove Background
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}

              {error && (
                <div className="mt-4 p-4 bg-red-500/20 border border-red-500 rounded-lg text-red-300">
                  {error}
                </div>
              )}
            </div>

            {/* Result Section */}
            <div className="bg-gray-800 rounded-xl p-6">
              <div className="h-full flex flex-col">
                <h3 className="text-xl font-semibold mb-4">Result</h3>
                {processedImage ? (
                  <div className="flex-1 flex flex-col">
                    <div className="flex-1 bg-gray-700 rounded-lg p-2">
                      <img
                        src={processedImage}
                        alt="Processed"
                        className="w-full h-full object-contain rounded"
                      />
                    </div>
                    <button
                      onClick={handleDownload}
                      className="mt-4 flex items-center justify-center px-4 py-2 bg-green-600 hover:bg-green-700 rounded-lg transition-colors"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Download Image
                    </button>
                  </div>
                ) : (
                  <div className="flex-1 flex items-center justify-center border-2 border-dashed border-gray-700 rounded-lg">
                    <p className="text-gray-500">
                      Processed image will appear here
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Features Section */}
          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-gray-800 p-6 rounded-xl">
              <h3 className="text-lg font-semibold mb-2">AI-Powered</h3>
              <p className="text-gray-400">
                Advanced AI algorithms for precise background removal
              </p>
            </div>
            <div className="bg-gray-800 p-6 rounded-xl">
              <h3 className="text-lg font-semibold mb-2">Fast Processing</h3>
              <p className="text-gray-400">
                Get results in seconds, not minutes
              </p>
            </div>
            <div className="bg-gray-800 p-6 rounded-xl">
              <h3 className="text-lg font-semibold mb-2">High Quality</h3>
              <p className="text-gray-400">
                Maintain original image quality with precise edge detection
              </p>
            </div>
          </div>
        </div>
      </div>

      <SampleImages />
    </div>
  );
}

export default App;